/* ---------------------Code converted to c-----------------------------*/ 
#include "kappalib.h"


#include <math.h> 

int main () {
int n1, n2, n3;
writeStr("Enter three different numbers: ");
writeStr("");
n1 = readInteger();

n2 = readInteger();

n3 = readInteger();

if (n1 >=  n2){

if (n1 >=  n3){

writeStr("Number 1 is the largest number.");
} 
else{
writeStr("Number 3 is the largest number.");
}
} 
else{
if (n2 >=  n3){

writeStr("Number 2 is the largest number.");
} 
else{
writeStr("Number 3 is the largest number.");
}
}
}


