/* ---------------------Code converted to c-----------------------------*/ 
#include "kappalib.h"


#include <math.h> 

int main () {
int i, j, rows;
writeStr("Enter the number of rows: ");
rows = readInteger();

for (int i = 1; i<rows; i+=1){

for (int j = 1; j<i; j+=1){

writeStr("* ");
}
writeStr("\n");
}
return 0;

}

