/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 1 "myanalyzer.y"

#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>		
#include "cgen.h"

extern int yylex(void);
extern int line_num;
char* compfunc1;
char* compfunc2;
char* compfunc3;

#line 85 "myanalyzer.tab.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "myanalyzer.tab.h"
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_token_ident = 3,                /* token_ident  */
  YYSYMBOL_token_number = 4,               /* token_number  */
  YYSYMBOL_token_real = 5,                 /* token_real  */
  YYSYMBOL_token_constring = 6,            /* token_constring  */
  YYSYMBOL_token_int = 7,                  /* token_int  */
  YYSYMBOL_token_scalar = 8,               /* token_scalar  */
  YYSYMBOL_token_string = 9,               /* token_string  */
  YYSYMBOL_token_boolean = 10,             /* token_boolean  */
  YYSYMBOL_token_true = 11,                /* token_true  */
  YYSYMBOL_token_false = 12,               /* token_false  */
  YYSYMBOL_token_star = 13,                /* token_star  */
  YYSYMBOL_token_constant = 14,            /* token_constant  */
  YYSYMBOL_token_if = 15,                  /* token_if  */
  YYSYMBOL_token_else = 16,                /* token_else  */
  YYSYMBOL_token_endif = 17,               /* token_endif  */
  YYSYMBOL_token_for = 18,                 /* token_for  */
  YYSYMBOL_token_in = 19,                  /* token_in  */
  YYSYMBOL_token_endfor = 20,              /* token_endfor  */
  YYSYMBOL_token_while = 21,               /* token_while  */
  YYSYMBOL_token_endwhile = 22,            /* token_endwhile  */
  YYSYMBOL_token_break = 23,               /* token_break  */
  YYSYMBOL_token_continue = 24,            /* token_continue  */
  YYSYMBOL_logic_not = 25,                 /* logic_not  */
  YYSYMBOL_logic_and = 26,                 /* logic_and  */
  YYSYMBOL_logic_or = 27,                  /* logic_or  */
  YYSYMBOL_token_def = 28,                 /* token_def  */
  YYSYMBOL_token_enddef = 29,              /* token_enddef  */
  YYSYMBOL_token_main = 30,                /* token_main  */
  YYSYMBOL_token_return = 31,              /* token_return  */
  YYSYMBOL_token_comp = 32,                /* token_comp  */
  YYSYMBOL_token_endcomp = 33,             /* token_endcomp  */
  YYSYMBOL_token_of = 34,                  /* token_of  */
  YYSYMBOL_op_lessequal = 35,              /* op_lessequal  */
  YYSYMBOL_op_moreequal = 36,              /* op_moreequal  */
  YYSYMBOL_op_noequal = 37,                /* op_noequal  */
  YYSYMBOL_op_equal = 38,                  /* op_equal  */
  YYSYMBOL_op_assign = 39,                 /* op_assign  */
  YYSYMBOL_token_arrow = 40,               /* token_arrow  */
  YYSYMBOL_token_arrow2 = 41,              /* token_arrow2  */
  YYSYMBOL_token_positive = 42,            /* token_positive  */
  YYSYMBOL_token_negative = 43,            /* token_negative  */
  YYSYMBOL_token_void = 44,                /* token_void  */
  YYSYMBOL_45_ = 45,                       /* '<'  */
  YYSYMBOL_46_ = 46,                       /* '>'  */
  YYSYMBOL_47_ = 47,                       /* '+'  */
  YYSYMBOL_48_ = 48,                       /* '-'  */
  YYSYMBOL_49_ = 49,                       /* '*'  */
  YYSYMBOL_50_ = 50,                       /* '/'  */
  YYSYMBOL_51_ = 51,                       /* '%'  */
  YYSYMBOL_52_ = 52,                       /* '.'  */
  YYSYMBOL_53_ = 53,                       /* '('  */
  YYSYMBOL_54_ = 54,                       /* ')'  */
  YYSYMBOL_55_ = 55,                       /* '['  */
  YYSYMBOL_56_ = 56,                       /* ']'  */
  YYSYMBOL_57_ = 57,                       /* ':'  */
  YYSYMBOL_58_ = 58,                       /* ';'  */
  YYSYMBOL_59_ = 59,                       /* '#'  */
  YYSYMBOL_60_ = 60,                       /* ','  */
  YYSYMBOL_61_ = 61,                       /* '&'  */
  YYSYMBOL_YYACCEPT = 62,                  /* $accept  */
  YYSYMBOL_program = 63,                   /* program  */
  YYSYMBOL_main_body = 64,                 /* main_body  */
  YYSYMBOL_declaration_body = 65,          /* declaration_body  */
  YYSYMBOL_declarations = 66,              /* declarations  */
  YYSYMBOL_begining = 67,                  /* begining  */
  YYSYMBOL_function_declaration = 68,      /* function_declaration  */
  YYSYMBOL_function_body = 69,             /* function_body  */
  YYSYMBOL_parameters = 70,                /* parameters  */
  YYSYMBOL_function_call = 71,             /* function_call  */
  YYSYMBOL_function_input = 72,            /* function_input  */
  YYSYMBOL_const_declaration = 73,         /* const_declaration  */
  YYSYMBOL_assert_const = 74,              /* assert_const  */
  YYSYMBOL_many_const_variables = 75,      /* many_const_variables  */
  YYSYMBOL_data = 76,                      /* data  */
  YYSYMBOL_data_type = 77,                 /* data_type  */
  YYSYMBOL_bool_value = 78,                /* bool_value  */
  YYSYMBOL_variables = 79,                 /* variables  */
  YYSYMBOL_var_declaration = 80,           /* var_declaration  */
  YYSYMBOL_many_variables = 81,            /* many_variables  */
  YYSYMBOL_many_variables_emptyarray = 82, /* many_variables_emptyarray  */
  YYSYMBOL_many_variables_array = 83,      /* many_variables_array  */
  YYSYMBOL_complex_type = 84,              /* complex_type  */
  YYSYMBOL_complex_body = 85,              /* complex_body  */
  YYSYMBOL_function_declaration2 = 86,     /* function_declaration2  */
  YYSYMBOL_complex_variables = 87,         /* complex_variables  */
  YYSYMBOL_complex_variables_decl = 88,    /* complex_variables_decl  */
  YYSYMBOL_complex_variables_multiple = 89, /* complex_variables_multiple  */
  YYSYMBOL_complex_variables_multiple_emptyarray = 90, /* complex_variables_multiple_emptyarray  */
  YYSYMBOL_complex_variables_multiple_array = 91, /* complex_variables_multiple_array  */
  YYSYMBOL_total_statements = 92,          /* total_statements  */
  YYSYMBOL_first_statement = 93,           /* first_statement  */
  YYSYMBOL_assign_command = 94,            /* assign_command  */
  YYSYMBOL_break_command = 95,             /* break_command  */
  YYSYMBOL_continue_command = 96,          /* continue_command  */
  YYSYMBOL_return_command = 97,            /* return_command  */
  YYSYMBOL_if_command = 98,                /* if_command  */
  YYSYMBOL_while_command = 99,             /* while_command  */
  YYSYMBOL_for_command = 100,              /* for_command  */
  YYSYMBOL_final_type = 101,               /* final_type  */
  YYSYMBOL_final_type2 = 102,              /* final_type2  */
  YYSYMBOL_expr = 103,                     /* expr  */
  YYSYMBOL_expr_data = 104                 /* expr_data  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_int16 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  24
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   705

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  62
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  43
/* YYNRULES -- Number of rules.  */
#define YYNRULES  141
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  433

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   299


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,    59,     2,    51,    61,     2,
      53,    54,    49,    47,    60,    48,    52,    50,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    57,    58,
      45,     2,    46,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    55,     2,    56,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,    48,    48,    58,    59,    63,    64,    68,    69,    70,
      71,    74,    78,    79,    80,    85,    86,    87,    88,    89,
      91,    92,    94,    99,   100,   101,   102,   103,   104,   108,
     113,   114,   115,   116,   117,   118,   119,   126,   129,   130,
     134,   135,   140,   147,   148,   149,   150,   154,   155,   160,
     163,   164,   165,   166,   167,   168,   169,   173,   174,   178,
     179,   183,   184,   189,   194,   195,   196,   197,   201,   209,
     212,   213,   214,   215,   216,   217,   218,   222,   223,   227,
     228,   232,   233,   241,   242,   246,   247,   248,   249,   250,
     251,   252,   253,   258,   260,   262,   264,   266,   268,   270,
     272,   274,   279,   283,   287,   288,   292,   293,   297,   301,
     303,   308,   310,   314,   320,   321,   322,   323,   324,   325,
     326,   327,   328,   329,   330,   331,   332,   333,   334,   335,
     336,   337,   338,   339,   340,   341,   345,   346,   347,   348,
     349,   350
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "token_ident",
  "token_number", "token_real", "token_constring", "token_int",
  "token_scalar", "token_string", "token_boolean", "token_true",
  "token_false", "token_star", "token_constant", "token_if", "token_else",
  "token_endif", "token_for", "token_in", "token_endfor", "token_while",
  "token_endwhile", "token_break", "token_continue", "logic_not",
  "logic_and", "logic_or", "token_def", "token_enddef", "token_main",
  "token_return", "token_comp", "token_endcomp", "token_of",
  "op_lessequal", "op_moreequal", "op_noequal", "op_equal", "op_assign",
  "token_arrow", "token_arrow2", "token_positive", "token_negative",
  "token_void", "'<'", "'>'", "'+'", "'-'", "'*'", "'/'", "'%'", "'.'",
  "'('", "')'", "'['", "']'", "':'", "';'", "'#'", "','", "'&'", "$accept",
  "program", "main_body", "declaration_body", "declarations", "begining",
  "function_declaration", "function_body", "parameters", "function_call",
  "function_input", "const_declaration", "assert_const",
  "many_const_variables", "data", "data_type", "bool_value", "variables",
  "var_declaration", "many_variables", "many_variables_emptyarray",
  "many_variables_array", "complex_type", "complex_body",
  "function_declaration2", "complex_variables", "complex_variables_decl",
  "complex_variables_multiple", "complex_variables_multiple_emptyarray",
  "complex_variables_multiple_array", "total_statements",
  "first_statement", "assign_command", "break_command", "continue_command",
  "return_command", "if_command", "while_command", "for_command",
  "final_type", "final_type2", "expr", "expr_data", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-262)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-35)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
     161,    90,    12,     6,    48,    68,  -262,   161,  -262,  -262,
    -262,  -262,  -262,    30,  -262,     1,   249,    89,   -19,    58,
    -262,    84,    96,    86,  -262,  -262,  -262,  -262,   102,    57,
    -262,  -262,  -262,  -262,  -262,  -262,  -262,   318,   167,   148,
     184,   111,   260,   157,   318,   195,   158,  -262,  -262,   -22,
    -262,  -262,  -262,  -262,  -262,   148,   148,   148,   148,   224,
    -262,   162,  -262,   599,  -262,    81,   125,   186,   116,   181,
     252,   216,   202,   228,   284,   119,   299,   248,   274,   260,
     260,   255,    31,  -262,  -262,  -262,  -262,  -262,  -262,  -262,
     318,   314,   169,  -262,   275,   318,   326,   115,   153,   616,
     321,   321,   521,  -262,   318,   332,   207,   148,   148,   148,
     148,   148,   148,   148,   148,   148,   148,   148,   148,   148,
     148,   281,   302,   -28,    31,   148,   177,   148,   327,   148,
    -262,  -262,   312,  -262,   409,    56,  -262,   298,  -262,  -262,
    -262,   182,   363,  -262,    31,    31,    31,    31,    31,    31,
    -262,   316,   318,   369,   319,  -262,   325,   290,   371,   322,
     381,   330,   333,  -262,   334,   352,   318,   394,   321,   616,
     616,    51,    51,   303,   303,    51,    51,    83,    83,   321,
     321,   321,   343,  -262,   341,   176,    31,   373,   426,   347,
     348,   547,   350,   573,   355,  -262,    13,     4,   354,   351,
     219,  -262,   356,     0,   -25,  -262,  -262,  -262,  -262,  -262,
    -262,   408,  -262,   358,  -262,   359,   361,   201,  -262,  -262,
     115,  -262,  -262,  -262,   148,   366,   382,   318,   184,   357,
     368,   404,   379,  -262,   399,   401,   385,   148,   386,   410,
     390,   392,   407,   393,   225,  -262,  -262,   465,   318,   411,
     466,   424,   478,   427,   481,  -262,   483,   435,  -262,  -262,
    -262,   148,   432,  -262,    31,    31,   436,  -262,   490,   148,
     375,   495,   375,   318,  -262,   506,   508,   233,   318,   453,
     237,  -262,  -262,   510,   221,   472,    26,   471,   470,  -262,
     473,  -262,   482,  -262,   184,   498,   509,  -262,   139,   484,
     452,   534,   230,  -262,   148,   277,   492,   493,   501,   318,
     480,   313,  -262,   550,   318,   496,  -262,   557,   549,   558,
    -262,  -262,  -262,   505,   507,   561,   574,  -262,   572,  -262,
     539,   522,   523,  -262,   469,   529,    31,  -262,   576,  -262,
     585,   318,   530,   535,  -262,   588,   584,   586,   587,  -262,
    -262,   553,   551,   545,   375,  -262,   556,   610,  -262,   601,
     568,   562,  -262,   613,   575,   577,   625,   630,   635,   589,
     581,  -262,   185,   375,   600,   582,   637,   638,   602,  -262,
     603,   598,   611,   612,   607,  -262,   614,   300,   617,  -262,
     606,   615,   666,  -262,   669,   318,   671,   672,  -262,   619,
     375,   627,  -262,   623,   624,   662,   626,   628,  -262,   364,
     679,  -262,   631,   681,   632,  -262,   629,   633,   318,   651,
     318,  -262,  -262,   634,   686,   636,  -262,   639,  -262,   640,
     685,   641,  -262
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,     0,     0,     0,     0,     0,     2,     0,     6,     4,
      10,     9,     7,     0,     8,     0,     0,     0,     0,     0,
      37,     0,     0,     0,     1,     5,     3,    49,     0,     0,
      52,    43,    44,    45,    46,    50,    58,     0,     0,     0,
      23,     0,    64,     0,     0,     0,     0,    51,    57,   136,
     139,   140,   137,    47,    48,     0,     0,     0,     0,     0,
     116,     0,   141,    42,   114,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    64,
      64,     0,    15,    85,    89,    90,    91,    86,    87,    88,
       0,     0,     0,    53,     0,     0,     0,    30,     0,   134,
     119,   118,     0,   115,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    15,     0,     0,     0,     0,     0,
     102,   103,     0,   105,     0,     0,    92,     0,    67,    65,
      69,     0,     0,    66,    15,    15,    15,    15,    15,    15,
      54,     0,     0,     0,     0,    55,     0,   136,     0,     0,
      32,     0,     0,   135,     0,     0,     0,     0,   120,   132,
     133,   129,   131,   127,   126,   128,   130,   124,   125,   121,
     122,   123,     0,    25,    24,     0,    15,     0,     0,     0,
       0,     0,     0,     0,     0,   104,     0,     0,     0,     0,
       0,    63,     0,     0,     0,    17,    16,    19,    18,    20,
      21,     0,    56,     0,    60,     0,     0,     0,    36,    29,
      30,   117,   138,    38,     0,     0,     0,     0,    23,     0,
       0,     0,     0,    93,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    71,    70,     0,     0,     0,
       0,     0,     0,     0,     0,    59,     0,     0,    33,    41,
      39,     0,    27,    26,    15,    15,     0,    11,     0,     0,
       0,     0,     0,     0,   101,     0,     0,     0,     0,     0,
       0,    78,    72,     0,     0,     0,     0,     0,     0,    62,
       0,    35,   117,    40,    23,     0,     0,    13,     0,     0,
       0,     0,     0,    84,     0,     0,     0,     0,     0,     0,
       0,     0,    73,     0,     0,     0,    77,     0,     0,     0,
      22,    61,    28,     0,     0,     0,     0,    96,     0,    94,
       0,     0,     0,    83,     0,     0,    15,    99,     0,    75,
       0,     0,     0,     0,    74,     0,     0,     0,     0,    14,
      12,     0,     0,     0,     0,   106,     0,     0,   108,     0,
       0,     0,    76,     0,     0,     0,     0,     0,     0,     0,
       0,    97,     0,     0,     0,     0,     0,     0,     0,    80,
       0,     0,     0,     0,     0,    95,     0,     0,     0,    68,
       0,     0,     0,    79,     0,     0,     0,     0,   107,     0,
       0,     0,    82,     0,     0,     0,     0,     0,   110,     0,
       0,    81,     0,     0,     0,   100,     0,     0,     0,     0,
       0,   109,    98,     0,     0,     0,   111,     0,   112,     0,
       0,     0,   113
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -262,  -262,  -262,  -262,   689,   691,  -262,  -123,  -200,   -40,
     485,   103,  -262,  -262,  -211,   -37,  -262,   128,  -262,  -262,
    -262,  -262,  -262,   170,  -262,   -36,  -262,  -262,  -262,  -262,
    -261,   -32,  -262,  -262,  -262,  -262,  -262,  -262,  -262,  -262,
    -262,   -38,  -262
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
       0,     5,     6,     7,     8,     9,    10,   143,    66,    60,
     159,   144,    20,   106,    61,    35,    62,   145,    13,    18,
      46,    92,    14,    78,    79,   146,    81,   200,   280,   311,
     302,   147,    83,    84,    85,    86,    87,    88,    89,   148,
     149,    63,    64
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      47,   187,    77,   189,   251,    28,    80,    93,   243,    21,
      82,   305,   185,   259,   196,    19,   240,    99,   100,   101,
     102,   205,   206,   207,   208,   209,   210,   252,   263,   186,
     197,    97,   198,    98,   141,   199,    22,   134,    37,    77,
      77,    38,    77,    80,    80,     2,    69,    82,    82,    70,
     293,    23,    71,   150,    72,    73,    29,    29,   155,   160,
     244,   241,    75,   231,   107,   269,   242,   164,    24,   168,
     169,   170,   171,   172,   173,   174,   175,   176,   177,   178,
     179,   180,   181,    90,    77,   184,    91,   188,    27,   191,
     142,   193,    36,   372,   322,   196,   107,    39,   116,   117,
     118,   119,   120,    11,    77,    77,    77,    77,    77,    77,
      11,   197,   387,   198,    44,   212,   199,    45,   157,    50,
      51,    52,    49,    50,    51,    52,    53,    54,    12,   225,
      53,    54,   118,   119,   120,    12,   121,    40,   122,   409,
      55,   295,   296,    42,    55,    15,    77,    16,   230,    41,
      17,    49,    50,    51,    52,   125,   161,   162,    43,    53,
      54,   246,    56,    57,     1,    67,    56,    57,    58,    97,
      48,   126,    58,    55,    59,     2,   158,   133,    59,   123,
     189,   190,   160,    31,    32,    33,    34,    65,    68,     3,
     262,   325,    97,     4,   326,    56,    57,   327,    94,   271,
      69,    58,   386,    70,   257,   162,    71,    59,    72,    73,
     285,   282,   288,   359,    90,    95,    75,    91,    96,   104,
     229,   125,   105,   202,    77,    77,   152,   103,   299,   153,
      77,   300,    77,    68,   127,    97,   306,   203,   303,    16,
     303,   312,    17,   124,   301,    69,   331,   332,    70,   138,
     139,    71,    30,    72,    73,   128,    31,    32,    33,    34,
     130,    75,    77,    68,   166,    77,   334,   167,   317,   129,
     333,   318,   339,   333,    97,    69,   248,   344,    70,   249,
      68,    71,   278,    72,    73,   279,   131,   132,    74,   301,
     309,    75,    69,   310,   314,    70,    77,   315,    71,   335,
      72,    73,   135,    68,   362,   183,   136,   137,    75,    31,
      32,    33,    34,   140,    77,    69,   107,   151,    70,    76,
     399,    71,   303,    72,    73,    31,    32,    33,    34,   156,
     154,    75,    77,    77,   107,   165,   301,   182,   110,   111,
     333,   303,   216,    97,   -31,   217,   192,    77,   114,   115,
     116,   117,   118,   119,   120,   333,   201,   245,   405,   301,
      77,    31,    32,    33,    34,   194,   204,    68,   303,    77,
     341,   211,   213,   342,   218,   214,   219,   333,    68,    69,
     215,   423,    70,   425,   416,    71,   221,    72,    73,   222,
      69,   224,   223,    70,   107,    75,    71,   226,    72,    73,
     227,   228,   232,   234,   235,   237,    75,   108,   109,   239,
     247,   250,   253,   254,   264,   255,   110,   111,   112,   113,
     256,   261,   107,   301,   260,   265,   114,   115,   116,   117,
     118,   119,   120,   266,   301,   108,   109,   267,   268,   107,
     269,   220,   270,   272,   110,   111,   112,   113,   274,   277,
     273,   275,   108,   109,   114,   115,   116,   117,   118,   119,
     120,   110,   111,   112,   113,   107,   276,   195,   281,   284,
     283,   114,   115,   116,   117,   118,   119,   120,   108,   109,
     286,   287,   107,   289,   233,   290,   291,   110,   111,   112,
     113,   292,   294,   298,   297,   108,   109,   114,   115,   116,
     117,   118,   119,   120,   110,   111,   112,   113,   107,   307,
     329,   308,   313,   316,   114,   115,   116,   117,   118,   119,
     120,   108,   109,   319,    97,   356,   357,   323,   320,   321,
     110,   111,   112,   113,   107,   328,   -34,   330,   324,   340,
     114,   115,   116,   117,   118,   119,   120,   108,   109,   336,
     338,   337,   304,   343,   347,   345,   110,   111,   112,   113,
     107,   346,   348,   349,   351,   350,   114,   115,   116,   117,
     118,   119,   120,   108,   109,   163,   353,   352,   196,   354,
     360,   355,   110,   111,   112,   113,   107,   358,   361,   363,
     364,   365,   114,   115,   116,   117,   118,   119,   120,   108,
     109,   236,   366,   371,   367,   368,   369,   370,   110,   111,
     112,   113,   107,   373,   374,   376,   378,   377,   114,   115,
     116,   117,   118,   119,   120,   108,   109,   238,   381,   107,
     375,   379,   380,   382,   110,   111,   112,   113,   383,   385,
     389,   390,   391,   384,   114,   115,   116,   117,   118,   119,
     120,   110,   111,   112,   113,   394,   388,   392,   397,   393,
     401,   114,   115,   116,   117,   118,   119,   120,   395,   396,
     403,   402,   398,   404,   400,   406,   407,   408,   410,   411,
     412,   413,   414,   417,   419,   424,   415,   421,   418,   420,
     427,   422,   426,   431,   428,   429,    25,   430,    26,   432,
       0,     0,     0,     0,     0,   258
};

static const yytype_int16 yycheck[] =
{
      37,   124,    42,     3,     4,     4,    42,    44,     4,     3,
      42,   272,    40,   224,    39,     3,     3,    55,    56,    57,
      58,   144,   145,   146,   147,   148,   149,    52,   228,    57,
      55,    53,    57,    55,     3,    60,    30,    75,    57,    79,
      80,    60,    82,    79,    80,    14,    15,    79,    80,    18,
     261,     3,    21,    90,    23,    24,    56,    56,    95,    97,
      56,    48,    31,   186,    13,    39,    53,   104,     0,   107,
     108,   109,   110,   111,   112,   113,   114,   115,   116,   117,
     118,   119,   120,    57,   124,   122,    60,   125,    58,   127,
      59,   129,     3,   354,   294,    39,    13,    39,    47,    48,
      49,    50,    51,     0,   144,   145,   146,   147,   148,   149,
       7,    55,   373,    57,    57,   152,    60,    60,     3,     4,
       5,     6,     3,     4,     5,     6,    11,    12,     0,   166,
      11,    12,    49,    50,    51,     7,    55,    53,    57,   400,
      25,   264,   265,    57,    25,    55,   186,    57,   185,    53,
      60,     3,     4,     5,     6,    39,     3,     4,    56,    11,
      12,   198,    47,    48,     3,    54,    47,    48,    53,    53,
       3,    55,    53,    25,    59,    14,    61,    58,    59,    54,
       3,     4,   220,     7,     8,     9,    10,     3,     3,    28,
     227,    52,    53,    32,    55,    47,    48,    58,     3,   237,
      15,    53,    17,    18,     3,     4,    21,    59,    23,    24,
     250,   248,   252,   336,    57,    57,    31,    60,    60,    57,
      44,    39,    60,    41,   264,   265,    57,     3,   268,    60,
     270,   269,   272,     3,    53,    53,   273,    55,   270,    57,
     272,   278,    60,    57,    59,    15,    16,    17,    18,    79,
      80,    21,     3,    23,    24,     3,     7,     8,     9,    10,
      58,    31,   302,     3,    57,   305,   304,    60,    47,    53,
     302,    50,   309,   305,    53,    15,    57,   314,    18,    60,
       3,    21,    57,    23,    24,    60,    58,     3,    28,    59,
      57,    31,    15,    60,    57,    18,   336,    60,    21,    22,
      23,    24,     3,     3,   341,     3,    58,    33,    31,     7,
       8,     9,    10,    58,   354,    15,    13,     3,    18,    59,
      20,    21,   354,    23,    24,     7,     8,     9,    10,     3,
      55,    31,   372,   373,    13,     3,    59,    56,    35,    36,
     372,   373,    52,    53,    54,    55,    19,   387,    45,    46,
      47,    48,    49,    50,    51,   387,    58,     3,   395,    59,
     400,     7,     8,     9,    10,    53,     3,     3,   400,   409,
      57,    55,     3,    60,     3,    56,    54,   409,     3,    15,
      55,   418,    18,   420,    20,    21,    56,    23,    24,    56,
      15,    39,    58,    18,    13,    31,    21,     3,    23,    24,
      57,    60,    29,    56,    56,    55,    31,    26,    27,    54,
      59,    55,     4,    55,    57,    56,    35,    36,    37,    38,
      59,    39,    13,    59,    58,    57,    45,    46,    47,    48,
      49,    50,    51,    29,    59,    26,    27,    58,    39,    13,
      39,    60,    57,    57,    35,    36,    37,    38,    58,    56,
      40,    59,    26,    27,    45,    46,    47,    48,    49,    50,
      51,    35,    36,    37,    38,    13,    59,    58,     3,     3,
      59,    45,    46,    47,    48,    49,    50,    51,    26,    27,
      56,     3,    13,    56,    58,     4,     3,    35,    36,    37,
      38,    56,    60,     3,    58,    26,    27,    45,    46,    47,
      48,    49,    50,    51,    35,    36,    37,    38,    13,     3,
      58,     3,    59,     3,    45,    46,    47,    48,    49,    50,
      51,    26,    27,    51,    53,    56,    57,    29,    58,    56,
      35,    36,    37,    38,    13,    51,    54,     3,    29,    59,
      45,    46,    47,    48,    49,    50,    51,    26,    27,    57,
      49,    58,    57,     3,     5,    59,    35,    36,    37,    38,
      13,     4,     4,    58,     3,    58,    45,    46,    47,    48,
      49,    50,    51,    26,    27,    54,     4,     3,    39,    57,
       4,    58,    35,    36,    37,    38,    13,    58,     3,    59,
      55,     3,    45,    46,    47,    48,    49,    50,    51,    26,
      27,    54,    18,    58,    18,    18,    53,    56,    35,    36,
      37,    38,    13,    57,     4,    47,     3,    55,    45,    46,
      47,    48,    49,    50,    51,    26,    27,    54,     3,    13,
      29,    56,    55,     3,    35,    36,    37,    38,     3,    58,
      58,     4,     4,    54,    45,    46,    47,    48,    49,    50,
      51,    35,    36,    37,    38,    57,    56,    55,    51,    56,
      54,    45,    46,    47,    48,    49,    50,    51,    57,    57,
       4,    56,    58,     4,    57,     4,     4,    58,    51,    56,
      56,    19,    56,     4,     3,    34,    58,    58,    57,    57,
       4,    58,    58,     8,    58,    56,     7,    57,     7,    58,
      -1,    -1,    -1,    -1,    -1,   220
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int8 yystos[] =
{
       0,     3,    14,    28,    32,    63,    64,    65,    66,    67,
      68,    73,    79,    80,    84,    55,    57,    60,    81,     3,
      74,     3,    30,     3,     0,    66,    67,    58,     4,    56,
       3,     7,     8,     9,    10,    77,     3,    57,    60,    39,
      53,    53,    57,    56,    57,    60,    82,    77,     3,     3,
       4,     5,     6,    11,    12,    25,    47,    48,    53,    59,
      71,    76,    78,   103,   104,     3,    70,    54,     3,    15,
      18,    21,    23,    24,    28,    31,    59,    71,    85,    86,
      87,    88,    93,    94,    95,    96,    97,    98,    99,   100,
      57,    60,    83,    77,     3,    57,    60,    53,    55,   103,
     103,   103,   103,     3,    57,    60,    75,    13,    26,    27,
      35,    36,    37,    38,    45,    46,    47,    48,    49,    50,
      51,    55,    57,    54,    57,    39,    55,    53,     3,    53,
      58,    58,     3,    58,   103,     3,    58,    33,    85,    85,
      58,     3,    59,    69,    73,    79,    87,    93,   101,   102,
      77,     3,    57,    60,    55,    77,     3,     3,    61,    72,
     103,     3,     4,    54,    77,     3,    57,    60,   103,   103,
     103,   103,   103,   103,   103,   103,   103,   103,   103,   103,
     103,   103,    56,     3,    77,    40,    57,    69,   103,     3,
       4,   103,    19,   103,    53,    58,    39,    55,    57,    60,
      89,    58,    41,    55,     3,    69,    69,    69,    69,    69,
      69,    55,    77,     3,    56,    55,    52,    55,     3,    54,
      60,    56,    56,    58,    39,    77,     3,    57,    60,    44,
      77,    69,    29,    58,    56,    56,    54,    55,    54,    54,
       3,    48,    53,     4,    56,     3,    77,    59,    57,    60,
      55,     4,    52,     4,    55,    56,    59,     3,    72,    76,
      58,    39,    77,    70,    57,    57,    29,    58,    39,    39,
      57,   103,    57,    40,    58,    59,    59,    56,    57,    60,
      90,     3,    77,    59,     3,    71,    56,     3,    71,    56,
       4,     3,    56,    76,    60,    69,    69,    58,     3,    71,
     103,    59,    92,    93,    57,    92,    77,     3,     3,    57,
      60,    91,    77,    59,    57,    60,     3,    47,    50,    51,
      58,    56,    70,    29,    29,    52,    55,    58,    51,    58,
       3,    16,    17,    93,   103,    22,    57,    58,    49,    77,
      59,    57,    60,     3,    77,    59,     4,     5,     4,    58,
      58,     3,     3,     4,    57,    58,    56,    57,    58,    69,
       4,     3,    77,    59,    55,     3,    18,    18,    18,    53,
      56,    58,    92,    57,     4,    29,    47,    55,     3,    56,
      55,     3,     3,     3,    54,    58,    17,    92,    56,    58,
       4,     4,    55,    56,    57,    57,    57,    51,    58,    20,
      57,    54,    56,     4,     4,    77,     4,     4,    58,    92,
      51,    56,    56,    19,    56,    58,    20,     4,    57,     3,
      57,    58,    58,    77,    34,    77,    58,     4,    58,    56,
      57,     8,    58
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr1[] =
{
       0,    62,    63,    64,    64,    65,    65,    66,    66,    66,
      66,    67,    68,    68,    68,    69,    69,    69,    69,    69,
      69,    69,    69,    70,    70,    70,    70,    70,    70,    71,
      72,    72,    72,    72,    72,    72,    72,    73,    74,    74,
      75,    75,    76,    77,    77,    77,    77,    78,    78,    79,
      80,    80,    80,    80,    80,    80,    80,    81,    81,    82,
      82,    83,    83,    84,    85,    85,    85,    85,    86,    87,
      88,    88,    88,    88,    88,    88,    88,    89,    89,    90,
      90,    91,    91,    92,    92,    93,    93,    93,    93,    93,
      93,    93,    93,    94,    94,    94,    94,    94,    94,    94,
      94,    94,    95,    96,    97,    97,    98,    98,    99,   100,
     100,   101,   101,   102,   103,   103,   103,   103,   103,   103,
     103,   103,   103,   103,   103,   103,   103,   103,   103,   103,
     103,   103,   103,   103,   103,   103,   104,   104,   104,   104,
     104,   104
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     1,     2,     1,     2,     1,     1,     1,     1,
       1,     8,    11,     9,    11,     0,     2,     2,     2,     2,
       2,     2,     5,     0,     3,     3,     5,     5,     7,     4,
       0,     1,     1,     3,     4,     4,     2,     2,     6,     7,
       5,     4,     1,     1,     1,     1,     1,     1,     1,     2,
       3,     4,     3,     5,     6,     6,     7,     3,     2,     5,
       4,     6,     5,     6,     0,     2,     2,     2,    10,     2,
       4,     4,     5,     6,     7,     7,     8,     4,     3,     6,
       5,     7,     6,     2,     1,     1,     1,     1,     1,     1,
       1,     1,     2,     4,     7,    10,     7,     9,    14,     7,
      13,     5,     2,     2,     3,     2,     8,    11,     8,    14,
      12,    14,    14,    18,     1,     2,     1,     4,     2,     2,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     2,     3,     1,     1,     4,     1,
       1,     1
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)




# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)]);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep)
{
  YY_USE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* program: main_body  */
#line 48 "myanalyzer.y"
                  {
if (yyerror_count == 0) {    
    printf("\n/* ---------------------Code converted to c-----------------------------*/ \n");    
    puts(c_prologue); 
    puts("#include <math.h> \n"); 
    printf("%s\n\n",(yyvsp[0].str));
  }
}
#line 1514 "myanalyzer.tab.c"
    break;

  case 3: /* main_body: declaration_body begining  */
#line 58 "myanalyzer.y"
                            { (yyval.str) = template("%s\n%s\n",(yyvsp[-1].str),(yyvsp[0].str)); }
#line 1520 "myanalyzer.tab.c"
    break;

  case 4: /* main_body: begining  */
#line 59 "myanalyzer.y"
             { (yyval.str) = (yyvsp[0].str); }
#line 1526 "myanalyzer.tab.c"
    break;

  case 5: /* declaration_body: declaration_body declarations  */
#line 63 "myanalyzer.y"
                                { (yyval.str) = template("%s\n%s", (yyvsp[-1].str), (yyvsp[0].str)); }
#line 1532 "myanalyzer.tab.c"
    break;

  case 6: /* declaration_body: declarations  */
#line 64 "myanalyzer.y"
                 { (yyval.str) = (yyvsp[0].str); }
#line 1538 "myanalyzer.tab.c"
    break;

  case 7: /* declarations: variables  */
#line 68 "myanalyzer.y"
            { (yyval.str) = (yyvsp[0].str); }
#line 1544 "myanalyzer.tab.c"
    break;

  case 8: /* declarations: complex_type  */
#line 69 "myanalyzer.y"
                 { (yyval.str) = (yyvsp[0].str); }
#line 1550 "myanalyzer.tab.c"
    break;

  case 9: /* declarations: const_declaration  */
#line 70 "myanalyzer.y"
                      { (yyval.str) = (yyvsp[0].str); }
#line 1556 "myanalyzer.tab.c"
    break;

  case 10: /* declarations: function_declaration  */
#line 71 "myanalyzer.y"
                         { (yyval.str) = (yyvsp[0].str); }
#line 1562 "myanalyzer.tab.c"
    break;

  case 11: /* begining: token_def token_main '(' ')' ':' function_body token_enddef ';'  */
#line 74 "myanalyzer.y"
                                                                          {(yyval.str) = template("int main () {\n%s\n}", (yyvsp[-2].str)); }
#line 1568 "myanalyzer.tab.c"
    break;

  case 12: /* function_declaration: token_def token_ident '(' parameters ')' token_arrow data_type ':' function_body token_enddef ';'  */
#line 78 "myanalyzer.y"
                                                                                                    {(yyval.str) = template("%s %s (%s) {\n%s\n}", (yyvsp[-4].str), (yyvsp[-9].str), (yyvsp[-7].str), (yyvsp[-2].str));}
#line 1574 "myanalyzer.tab.c"
    break;

  case 13: /* function_declaration: token_def token_ident '(' parameters ')' ':' function_body token_enddef ';'  */
#line 79 "myanalyzer.y"
                                                                                                        {(yyval.str) = template("void %s (%s) {\n%s\n}", (yyvsp[-7].str), (yyvsp[-5].str), (yyvsp[-2].str));}
#line 1580 "myanalyzer.tab.c"
    break;

  case 14: /* function_declaration: token_def token_ident '(' parameters ')' token_arrow token_void ':' function_body token_enddef ';'  */
#line 80 "myanalyzer.y"
                                                                                                    {(yyval.str) = template("void %s (%s) {\n%s\n}", (yyvsp[-9].str), (yyvsp[-7].str), (yyvsp[-2].str));}
#line 1586 "myanalyzer.tab.c"
    break;

  case 15: /* function_body: %empty  */
#line 85 "myanalyzer.y"
                       {(yyval.str) = template("");}
#line 1592 "myanalyzer.tab.c"
    break;

  case 16: /* function_body: variables function_body  */
#line 86 "myanalyzer.y"
                                   {(yyval.str) = template("%s%s", (yyvsp[-1].str), (yyvsp[0].str));}
#line 1598 "myanalyzer.tab.c"
    break;

  case 17: /* function_body: const_declaration function_body  */
#line 87 "myanalyzer.y"
                                         {(yyval.str) = template("%s%s", (yyvsp[-1].str), (yyvsp[0].str));}
#line 1604 "myanalyzer.tab.c"
    break;

  case 18: /* function_body: first_statement function_body  */
#line 88 "myanalyzer.y"
                                       {(yyval.str) = template("%s%s", (yyvsp[-1].str), (yyvsp[0].str));}
#line 1610 "myanalyzer.tab.c"
    break;

  case 19: /* function_body: complex_variables function_body  */
#line 89 "myanalyzer.y"
                                           {(yyval.str) = template("\t%s%s", (yyvsp[-1].str), (yyvsp[0].str));}
#line 1616 "myanalyzer.tab.c"
    break;

  case 20: /* function_body: final_type function_body  */
#line 91 "myanalyzer.y"
                           {(yyval.str) = template("\t%s%s", (yyvsp[-1].str), (yyvsp[0].str));}
#line 1622 "myanalyzer.tab.c"
    break;

  case 21: /* function_body: final_type2 function_body  */
#line 92 "myanalyzer.y"
                            {(yyval.str) = template("\t%s%s", (yyvsp[-1].str), (yyvsp[0].str));}
#line 1628 "myanalyzer.tab.c"
    break;

  case 22: /* function_body: '#' token_ident '.' function_call ';'  */
#line 94 "myanalyzer.y"
                                        {(yyval.str) = template("%s.%s;",(yyvsp[-3].str),(yyvsp[-1].str));}
#line 1634 "myanalyzer.tab.c"
    break;

  case 23: /* parameters: %empty  */
#line 99 "myanalyzer.y"
                                                        {(yyval.str) = template("");}
#line 1640 "myanalyzer.tab.c"
    break;

  case 24: /* parameters: token_ident ':' data_type  */
#line 100 "myanalyzer.y"
                                                        {(yyval.str) = template("%s %s", (yyvsp[0].str), (yyvsp[-2].str));}
#line 1646 "myanalyzer.tab.c"
    break;

  case 25: /* parameters: token_ident ':' token_ident  */
#line 101 "myanalyzer.y"
                                                        {(yyval.str) = template("%s %s",(yyvsp[0].str),(yyvsp[-2].str));}
#line 1652 "myanalyzer.tab.c"
    break;

  case 26: /* parameters: token_ident ':' data_type ',' parameters  */
#line 102 "myanalyzer.y"
                                                        {(yyval.str) = template("%s %s, %s", (yyvsp[-2].str), (yyvsp[-4].str), (yyvsp[0].str));}
#line 1658 "myanalyzer.tab.c"
    break;

  case 27: /* parameters: token_ident '[' ']' ':' data_type  */
#line 103 "myanalyzer.y"
                                                        {(yyval.str) = template("%s* %s", (yyvsp[0].str), (yyvsp[-4].str));}
#line 1664 "myanalyzer.tab.c"
    break;

  case 28: /* parameters: token_ident '[' ']' ':' data_type ',' parameters  */
#line 104 "myanalyzer.y"
                                                        {(yyval.str) = template("%s* %s, %s", (yyvsp[-2].str), (yyvsp[-6].str), (yyvsp[0].str));}
#line 1670 "myanalyzer.tab.c"
    break;

  case 29: /* function_call: token_ident '(' function_input ')'  */
#line 108 "myanalyzer.y"
                                   {(yyval.str) = template("%s(%s)", (yyvsp[-3].str), (yyvsp[-1].str));}
#line 1676 "myanalyzer.tab.c"
    break;

  case 30: /* function_input: %empty  */
#line 113 "myanalyzer.y"
                                {(yyval.str) = template("");}
#line 1682 "myanalyzer.tab.c"
    break;

  case 31: /* function_input: token_ident  */
#line 114 "myanalyzer.y"
                                { (yyval.str) = template("%s",(yyvsp[0].str)); }
#line 1688 "myanalyzer.tab.c"
    break;

  case 32: /* function_input: expr  */
#line 115 "myanalyzer.y"
                        {(yyval.str) = (yyvsp[0].str);}
#line 1694 "myanalyzer.tab.c"
    break;

  case 33: /* function_input: expr ',' function_input  */
#line 116 "myanalyzer.y"
                                {(yyval.str) = template("%s , %s", (yyvsp[-2].str), (yyvsp[0].str));}
#line 1700 "myanalyzer.tab.c"
    break;

  case 34: /* function_input: token_ident '[' token_ident ']'  */
#line 117 "myanalyzer.y"
                                {(yyval.str) = template("%s[%s]", (yyvsp[-3].str), (yyvsp[-1].str));}
#line 1706 "myanalyzer.tab.c"
    break;

  case 35: /* function_input: token_ident '.' '#' token_ident  */
#line 118 "myanalyzer.y"
                                {(yyval.str) = template("%s.%s", (yyvsp[-3].str), (yyvsp[0].str));}
#line 1712 "myanalyzer.tab.c"
    break;

  case 36: /* function_input: '&' token_ident  */
#line 119 "myanalyzer.y"
                                {(yyval.str) = template("&%s", (yyvsp[0].str));}
#line 1718 "myanalyzer.tab.c"
    break;

  case 37: /* const_declaration: token_constant assert_const  */
#line 126 "myanalyzer.y"
                            { (yyval.str) = template("const %s;",(yyvsp[0].str));}
#line 1724 "myanalyzer.tab.c"
    break;

  case 38: /* assert_const: token_ident op_assign data ':' data_type ';'  */
#line 129 "myanalyzer.y"
                                                                        { (yyval.str) = template("%s %s = %s",(yyvsp[-1].str),(yyvsp[-5].str),(yyvsp[-3].str));}
#line 1730 "myanalyzer.tab.c"
    break;

  case 39: /* assert_const: token_ident op_assign data many_const_variables ':' data_type ';'  */
#line 130 "myanalyzer.y"
                                                                        { (yyval.str) = template("%s %s = %s, %s",(yyvsp[-1].str),(yyvsp[-6].str),(yyvsp[-4].str),(yyvsp[-3].str));}
#line 1736 "myanalyzer.tab.c"
    break;

  case 40: /* many_const_variables: many_const_variables ',' token_ident op_assign data  */
#line 134 "myanalyzer.y"
                                                        {(yyval.str) = template("%s, %s = %s",(yyvsp[-4].str),(yyvsp[-2].str),(yyvsp[0].str));}
#line 1742 "myanalyzer.tab.c"
    break;

  case 41: /* many_const_variables: ',' token_ident op_assign data  */
#line 135 "myanalyzer.y"
                                                        {(yyval.str) = template("%s = %s",(yyvsp[-2].str),(yyvsp[0].str));}
#line 1748 "myanalyzer.tab.c"
    break;

  case 42: /* data: expr  */
#line 140 "myanalyzer.y"
            { (yyval.str) = template("%s",(yyvsp[0].str)); }
#line 1754 "myanalyzer.tab.c"
    break;

  case 43: /* data_type: token_int  */
#line 147 "myanalyzer.y"
                { (yyval.str) = "int"; }
#line 1760 "myanalyzer.tab.c"
    break;

  case 44: /* data_type: token_scalar  */
#line 148 "myanalyzer.y"
                { (yyval.str) = "double"; }
#line 1766 "myanalyzer.tab.c"
    break;

  case 45: /* data_type: token_string  */
#line 149 "myanalyzer.y"
                { (yyval.str) = "char*"; }
#line 1772 "myanalyzer.tab.c"
    break;

  case 46: /* data_type: token_boolean  */
#line 150 "myanalyzer.y"
                { (yyval.str) = "int"; }
#line 1778 "myanalyzer.tab.c"
    break;

  case 47: /* bool_value: token_true  */
#line 154 "myanalyzer.y"
                {(yyval.str) = "1";}
#line 1784 "myanalyzer.tab.c"
    break;

  case 48: /* bool_value: token_false  */
#line 155 "myanalyzer.y"
                {(yyval.str) = "0";}
#line 1790 "myanalyzer.tab.c"
    break;

  case 49: /* variables: var_declaration ';'  */
#line 160 "myanalyzer.y"
                               { (yyval.str) = template("%s;",(yyvsp[-1].str)); }
#line 1796 "myanalyzer.tab.c"
    break;

  case 50: /* var_declaration: token_ident ':' data_type  */
#line 163 "myanalyzer.y"
                                                                        {(yyval.str) = template("%s %s",(yyvsp[0].str),(yyvsp[-2].str));}
#line 1802 "myanalyzer.tab.c"
    break;

  case 51: /* var_declaration: token_ident many_variables ':' data_type  */
#line 164 "myanalyzer.y"
                                                                        { (yyval.str) = template("%s %s%s",(yyvsp[0].str),(yyvsp[-3].str),(yyvsp[-2].str));}
#line 1808 "myanalyzer.tab.c"
    break;

  case 52: /* var_declaration: token_ident ':' token_ident  */
#line 165 "myanalyzer.y"
                                                                        {(yyval.str) = template("\n%s %s=ctor_%s",(yyvsp[0].str),(yyvsp[-2].str),(yyvsp[0].str));}
#line 1814 "myanalyzer.tab.c"
    break;

  case 53: /* var_declaration: token_ident '[' ']' ':' data_type  */
#line 166 "myanalyzer.y"
                                                                        {(yyval.str) = template("%s* %s", (yyvsp[0].str),(yyvsp[-4].str)); }
#line 1820 "myanalyzer.tab.c"
    break;

  case 54: /* var_declaration: token_ident '[' token_number ']' ':' data_type  */
#line 167 "myanalyzer.y"
                                                                        {(yyval.str) = template("\n%s %s[%s]", (yyvsp[0].str),(yyvsp[-5].str),(yyvsp[-3].str)); }
#line 1826 "myanalyzer.tab.c"
    break;

  case 55: /* var_declaration: token_ident '[' ']' many_variables_emptyarray ':' data_type  */
#line 168 "myanalyzer.y"
                                                                        { (yyval.str) = template("%s* %s%s",(yyvsp[0].str),(yyvsp[-5].str),(yyvsp[-2].str));}
#line 1832 "myanalyzer.tab.c"
    break;

  case 56: /* var_declaration: token_ident '[' token_number ']' many_variables_array ':' data_type  */
#line 169 "myanalyzer.y"
                                                                        { (yyval.str) = template("%s %s[%s]%s",(yyvsp[0].str),(yyvsp[-6].str),(yyvsp[-4].str),(yyvsp[-2].str));}
#line 1838 "myanalyzer.tab.c"
    break;

  case 57: /* many_variables: many_variables ',' token_ident  */
#line 173 "myanalyzer.y"
                                                { (yyval.str) = template("%s, %s",(yyvsp[-2].str),(yyvsp[0].str));}
#line 1844 "myanalyzer.tab.c"
    break;

  case 58: /* many_variables: ',' token_ident  */
#line 174 "myanalyzer.y"
                                                { (yyval.str) = template(", %s",(yyvsp[0].str));}
#line 1850 "myanalyzer.tab.c"
    break;

  case 59: /* many_variables_emptyarray: many_variables_emptyarray ',' token_ident '[' ']'  */
#line 178 "myanalyzer.y"
                                                                { (yyval.str) = template("%s, %s",(yyvsp[-4].str),(yyvsp[-2].str));}
#line 1856 "myanalyzer.tab.c"
    break;

  case 60: /* many_variables_emptyarray: ',' token_ident '[' ']'  */
#line 179 "myanalyzer.y"
                                                                { (yyval.str) = template(", %s",(yyvsp[-2].str));}
#line 1862 "myanalyzer.tab.c"
    break;

  case 61: /* many_variables_array: many_variables_array ',' token_ident '[' token_number ']'  */
#line 183 "myanalyzer.y"
                                                                { (yyval.str) = template("%s, %s[%s]",(yyvsp[-5].str),(yyvsp[-3].str),(yyvsp[-1].str));}
#line 1868 "myanalyzer.tab.c"
    break;

  case 62: /* many_variables_array: ',' token_ident '[' token_number ']'  */
#line 184 "myanalyzer.y"
                                                                { (yyval.str) = template(", %s[%s]",(yyvsp[-3].str),(yyvsp[-1].str));}
#line 1874 "myanalyzer.tab.c"
    break;

  case 63: /* complex_type: token_comp token_ident ':' complex_body token_endcomp ';'  */
#line 189 "myanalyzer.y"
                                                                        { (yyval.str) = template("#define SELF struct %s *self\ntypedef struct %s {\n%s\n%s\n}%s;\n%s\nconst %s ctor_%s = %s;\n#undef SELF",(yyvsp[-4].str),(yyvsp[-4].str),(yyvsp[-2].str),compfunc1,(yyvsp[-4].str),compfunc3,(yyvsp[-4].str),(yyvsp[-4].str),compfunc2); 
}
#line 1881 "myanalyzer.tab.c"
    break;

  case 64: /* complex_body: %empty  */
#line 194 "myanalyzer.y"
                                                        {(yyval.str) = template("");}
#line 1887 "myanalyzer.tab.c"
    break;

  case 65: /* complex_body: complex_variables complex_body  */
#line 195 "myanalyzer.y"
                                                        {(yyval.str) = template("%s%s", (yyvsp[-1].str), (yyvsp[0].str));}
#line 1893 "myanalyzer.tab.c"
    break;

  case 66: /* complex_body: first_statement function_body  */
#line 196 "myanalyzer.y"
                                                        {(yyval.str) = template("%s%s", (yyvsp[-1].str), (yyvsp[0].str));}
#line 1899 "myanalyzer.tab.c"
    break;

  case 67: /* complex_body: function_declaration2 complex_body  */
#line 197 "myanalyzer.y"
                                                                { (yyval.str) = template("%s",(yyvsp[-1].str),(yyvsp[0].str));}
#line 1905 "myanalyzer.tab.c"
    break;

  case 68: /* function_declaration2: token_def token_ident '(' ')' token_arrow data_type ':' function_body token_enddef ';'  */
#line 201 "myanalyzer.y"
                                                                                      {(yyval.str) = template("");     
 compfunc1 = strdup(template("%s(*%s)(SELF);",(yyvsp[-4].str),(yyvsp[-8].str))); 
 compfunc2 = strdup(template("{.%s=%s}", (yyvsp[-8].str),(yyvsp[-8].str))); 
 compfunc3 = strdup(template("%s %s(SELF ) \n{\n%s\n}",(yyvsp[-4].str),(yyvsp[-8].str),(yyvsp[-2].str)));
}
#line 1915 "myanalyzer.tab.c"
    break;

  case 69: /* complex_variables: complex_variables_decl ';'  */
#line 209 "myanalyzer.y"
                                              { (yyval.str) = template("%s;",(yyvsp[-1].str)); }
#line 1921 "myanalyzer.tab.c"
    break;

  case 70: /* complex_variables_decl: '#' token_ident ':' data_type  */
#line 212 "myanalyzer.y"
                                                                                        {(yyval.str) = template("%s %s",(yyvsp[0].str),(yyvsp[-2].str));}
#line 1927 "myanalyzer.tab.c"
    break;

  case 71: /* complex_variables_decl: '#' token_ident ':' token_ident  */
#line 213 "myanalyzer.y"
                                                                                        {(yyval.str) = template("%s %s",(yyvsp[0].str),(yyvsp[-2].str));}
#line 1933 "myanalyzer.tab.c"
    break;

  case 72: /* complex_variables_decl: '#' token_ident complex_variables_multiple ':' data_type  */
#line 214 "myanalyzer.y"
                                                                                                {(yyval.str) = template("%s %s%s",(yyvsp[0].str),(yyvsp[-3].str),(yyvsp[-2].str));}
#line 1939 "myanalyzer.tab.c"
    break;

  case 73: /* complex_variables_decl: '#' token_ident '[' ']' ':' data_type  */
#line 215 "myanalyzer.y"
                                                                                        {(yyval.str) = template("%s* %s", (yyvsp[0].str),(yyvsp[-4].str)); }
#line 1945 "myanalyzer.tab.c"
    break;

  case 74: /* complex_variables_decl: '#' token_ident '[' ']' complex_variables_multiple_emptyarray ':' data_type  */
#line 216 "myanalyzer.y"
                                                                                        {(yyval.str) = template("%s* %s%s",(yyvsp[0].str),(yyvsp[-5].str),(yyvsp[-2].str));}
#line 1951 "myanalyzer.tab.c"
    break;

  case 75: /* complex_variables_decl: '#' token_ident '[' token_number ']' ':' data_type  */
#line 217 "myanalyzer.y"
                                                                                        {(yyval.str) = template("%s %s[%s]", (yyvsp[0].str),(yyvsp[-5].str),(yyvsp[-3].str)); }
#line 1957 "myanalyzer.tab.c"
    break;

  case 76: /* complex_variables_decl: '#' token_ident '[' token_number ']' complex_variables_multiple_array ':' data_type  */
#line 218 "myanalyzer.y"
                                                                                        {(yyval.str) = template("%s %s[%s]%s",(yyvsp[0].str),(yyvsp[-6].str),(yyvsp[-4].str),(yyvsp[-2].str));}
#line 1963 "myanalyzer.tab.c"
    break;

  case 77: /* complex_variables_multiple: complex_variables_multiple ',' '#' token_ident  */
#line 222 "myanalyzer.y"
                                                        { (yyval.str) = template("%s, %s",(yyvsp[-3].str),(yyvsp[0].str));}
#line 1969 "myanalyzer.tab.c"
    break;

  case 78: /* complex_variables_multiple: ',' '#' token_ident  */
#line 223 "myanalyzer.y"
                                                        { (yyval.str) = template(", %s",(yyvsp[0].str));}
#line 1975 "myanalyzer.tab.c"
    break;

  case 79: /* complex_variables_multiple_emptyarray: complex_variables_multiple_emptyarray ',' '#' token_ident '[' ']'  */
#line 227 "myanalyzer.y"
                                                                        { (yyval.str) = template("%s, %s",(yyvsp[-5].str),(yyvsp[-2].str));}
#line 1981 "myanalyzer.tab.c"
    break;

  case 80: /* complex_variables_multiple_emptyarray: ',' '#' token_ident '[' ']'  */
#line 228 "myanalyzer.y"
                                                                        { (yyval.str) = template(", %s",(yyvsp[-2].str));}
#line 1987 "myanalyzer.tab.c"
    break;

  case 81: /* complex_variables_multiple_array: complex_variables_multiple_array ',' '#' token_ident '[' token_number ']'  */
#line 232 "myanalyzer.y"
                                                                                { (yyval.str) = template("%s, %s[%s]",(yyvsp[-6].str),(yyvsp[-3].str),(yyvsp[-1].str));}
#line 1993 "myanalyzer.tab.c"
    break;

  case 82: /* complex_variables_multiple_array: ',' '#' token_ident '[' token_number ']'  */
#line 233 "myanalyzer.y"
                                                                                { (yyval.str) = template(", %s[%s]",(yyvsp[-3].str),(yyvsp[-1].str));}
#line 1999 "myanalyzer.tab.c"
    break;

  case 83: /* total_statements: total_statements first_statement  */
#line 241 "myanalyzer.y"
                                 { (yyval.str) = template("%s%s", (yyvsp[-1].str),(yyvsp[0].str)); }
#line 2005 "myanalyzer.tab.c"
    break;

  case 84: /* total_statements: first_statement  */
#line 242 "myanalyzer.y"
                 { (yyval.str) = template("%s", (yyvsp[0].str)); }
#line 2011 "myanalyzer.tab.c"
    break;

  case 85: /* first_statement: assign_command  */
#line 246 "myanalyzer.y"
                        {(yyval.str) = template("%s\n", (yyvsp[0].str));}
#line 2017 "myanalyzer.tab.c"
    break;

  case 86: /* first_statement: if_command  */
#line 247 "myanalyzer.y"
                        {(yyval.str) = template("\n%s", (yyvsp[0].str));}
#line 2023 "myanalyzer.tab.c"
    break;

  case 87: /* first_statement: while_command  */
#line 248 "myanalyzer.y"
                        {(yyval.str) = template("%s", (yyvsp[0].str));}
#line 2029 "myanalyzer.tab.c"
    break;

  case 88: /* first_statement: for_command  */
#line 249 "myanalyzer.y"
                        {(yyval.str) = template("%s", (yyvsp[0].str));}
#line 2035 "myanalyzer.tab.c"
    break;

  case 89: /* first_statement: break_command  */
#line 250 "myanalyzer.y"
                        {(yyval.str) = template("%s\n", (yyvsp[0].str));}
#line 2041 "myanalyzer.tab.c"
    break;

  case 90: /* first_statement: continue_command  */
#line 251 "myanalyzer.y"
                        {(yyval.str) = template("%s", (yyvsp[0].str));}
#line 2047 "myanalyzer.tab.c"
    break;

  case 91: /* first_statement: return_command  */
#line 252 "myanalyzer.y"
                        {(yyval.str) = template("\n%s\n", (yyvsp[0].str));}
#line 2053 "myanalyzer.tab.c"
    break;

  case 92: /* first_statement: function_call ';'  */
#line 253 "myanalyzer.y"
                                {(yyval.str) = template("\n%s;", (yyvsp[-1].str));}
#line 2059 "myanalyzer.tab.c"
    break;

  case 93: /* assign_command: token_ident op_assign expr ';'  */
#line 259 "myanalyzer.y"
{ (yyval.str) = template("\n%s = %s;", (yyvsp[-3].str),(yyvsp[-1].str)); }
#line 2065 "myanalyzer.tab.c"
    break;

  case 94: /* assign_command: token_ident '[' token_number ']' op_assign expr ';'  */
#line 261 "myanalyzer.y"
{ (yyval.str) = template("%s[%s] = %s;", (yyvsp[-6].str),(yyvsp[-4].str),(yyvsp[-1].str)); }
#line 2071 "myanalyzer.tab.c"
    break;

  case 95: /* assign_command: token_ident '[' token_ident ']' op_assign token_ident '[' token_ident ']' ';'  */
#line 263 "myanalyzer.y"
{ (yyval.str) = template("%s[%s] =%s[%s];", (yyvsp[-9].str),(yyvsp[-7].str),(yyvsp[-4].str),(yyvsp[-2].str)); }
#line 2077 "myanalyzer.tab.c"
    break;

  case 96: /* assign_command: token_ident '[' token_ident ']' op_assign token_ident ';'  */
#line 265 "myanalyzer.y"
{ (yyval.str) = template("%s[%s] =%s;", (yyvsp[-6].str),(yyvsp[-4].str),(yyvsp[-1].str)); }
#line 2083 "myanalyzer.tab.c"
    break;

  case 97: /* assign_command: token_ident '[' token_ident ']' op_assign function_call '%' token_number ';'  */
#line 267 "myanalyzer.y"
{ (yyval.str) = template("%s[%s] = %s %% %s;", (yyvsp[-8].str),(yyvsp[-6].str),(yyvsp[-3].str),(yyvsp[-1].str)); }
#line 2089 "myanalyzer.tab.c"
    break;

  case 98: /* assign_command: '#' token_ident op_assign '(' '#' token_ident '*' token_number '+' token_number ')' '%' token_number ';'  */
#line 269 "myanalyzer.y"
{ (yyval.str) = template("self->%s = (self->%s * %s + %s ) %% %s;", (yyvsp[-12].str),(yyvsp[-8].str),(yyvsp[-6].str),(yyvsp[-4].str),(yyvsp[-1].str)); }
#line 2095 "myanalyzer.tab.c"
    break;

  case 99: /* assign_command: '#' token_ident op_assign '-' '#' token_ident ';'  */
#line 271 "myanalyzer.y"
{ (yyval.str) = template("self->%s =  - self->%s ;", (yyvsp[-5].str),(yyvsp[-1].str)); }
#line 2101 "myanalyzer.tab.c"
    break;

  case 100: /* assign_command: token_ident '[' token_ident ']' op_assign token_ident '.' token_ident '(' ')' '%' token_number ';'  */
#line 273 "myanalyzer.y"
{ (yyval.str) = template("%s[%s] = %s.%s(&%s) %% %s;", (yyvsp[-12].str),(yyvsp[-10].str),(yyvsp[-7].str),(yyvsp[-5].str),(yyvsp[-7].str),(yyvsp[-1].str)); }
#line 2107 "myanalyzer.tab.c"
    break;

  case 101: /* assign_command: '#' token_ident op_assign token_ident ';'  */
#line 275 "myanalyzer.y"
{ (yyval.str) = template("%s = %s;",(yyvsp[-3].str),(yyvsp[-1].str)); }
#line 2113 "myanalyzer.tab.c"
    break;

  case 102: /* break_command: token_break ';'  */
#line 279 "myanalyzer.y"
                { (yyval.str) = "break;"; }
#line 2119 "myanalyzer.tab.c"
    break;

  case 103: /* continue_command: token_continue ';'  */
#line 283 "myanalyzer.y"
                     { (yyval.str) = "continue;"; }
#line 2125 "myanalyzer.tab.c"
    break;

  case 104: /* return_command: token_return expr ';'  */
#line 287 "myanalyzer.y"
                                { (yyval.str) = template("return %s;", (yyvsp[-1].str)); }
#line 2131 "myanalyzer.tab.c"
    break;

  case 105: /* return_command: token_return ';'  */
#line 288 "myanalyzer.y"
                                { (yyval.str) = "return;"; }
#line 2137 "myanalyzer.tab.c"
    break;

  case 106: /* if_command: token_if '(' expr ')' ':' total_statements token_endif ';'  */
#line 292 "myanalyzer.y"
                                                                                                { (yyval.str) = template("if (%s){\n%s\n}",(yyvsp[-5].str),(yyvsp[-2].str)); }
#line 2143 "myanalyzer.tab.c"
    break;

  case 107: /* if_command: token_if '(' expr ')' ':' total_statements token_else ':' total_statements token_endif ';'  */
#line 293 "myanalyzer.y"
                                                                                                { (yyval.str) = template("if (%s){\n%s\n} \nelse{%s\n}",(yyvsp[-8].str),(yyvsp[-5].str),(yyvsp[-2].str)); }
#line 2149 "myanalyzer.tab.c"
    break;

  case 108: /* while_command: token_while '(' expr ')' ':' total_statements token_endwhile ';'  */
#line 297 "myanalyzer.y"
                                                                  { (yyval.str) = template("\nwhile(%s){\n%s\n} \n",(yyvsp[-5].str),(yyvsp[-2].str)); }
#line 2155 "myanalyzer.tab.c"
    break;

  case 109: /* for_command: token_for token_ident token_in '[' expr ':' expr ':' token_number ']' ':' total_statements token_endfor ';'  */
#line 302 "myanalyzer.y"
{ (yyval.str) = template("\nfor ( %s = %s; %s<%s; %s+=%s){\n%s\n}",(yyvsp[-12].str),(yyvsp[-9].str),(yyvsp[-12].str),(yyvsp[-7].str),(yyvsp[-12].str),(yyvsp[-5].str),(yyvsp[-2].str)); }
#line 2161 "myanalyzer.tab.c"
    break;

  case 110: /* for_command: token_for token_ident token_in '[' expr ':' expr ']' ':' total_statements token_endfor ';'  */
#line 304 "myanalyzer.y"
{ (yyval.str) = template("\nfor (int %s = %s; %s<%s; %s+=1){\n%s\n}",(yyvsp[-10].str),(yyvsp[-7].str),(yyvsp[-10].str),(yyvsp[-5].str),(yyvsp[-10].str),(yyvsp[-2].str)); }
#line 2167 "myanalyzer.tab.c"
    break;

  case 111: /* final_type: token_ident token_arrow2 '[' token_ident '+' token_number token_for token_ident ':' token_number ']' ':' data_type ';'  */
#line 309 "myanalyzer.y"
 { (yyval.str) = template("\n int *%s = (%s *)malloc(%s * sizeof(%s));\n for(%s %s = 0; %s < %s;++%s){\n%s[%s] = %s + %s;\n};  ",(yyvsp[-13].str),(yyvsp[-1].str),(yyvsp[-4].str),(yyvsp[-1].str),(yyvsp[-1].str),(yyvsp[-6].str),(yyvsp[-6].str),(yyvsp[-4].str),(yyvsp[-6].str),(yyvsp[-13].str),(yyvsp[-6].str),(yyvsp[-6].str),(yyvsp[-8].str)); }
#line 2173 "myanalyzer.tab.c"
    break;

  case 112: /* final_type: token_ident token_arrow2 '[' function_call '%' token_number token_for token_ident ':' token_number ']' ':' data_type ';'  */
#line 311 "myanalyzer.y"
{ (yyval.str) = template("\n int *%s = (%s *)malloc(%s * sizeof(%s));\n for(%s %s = 0; %s < %s;++%s){\n%s[%s] = %s ;\n};  ",(yyvsp[-13].str),(yyvsp[-1].str),(yyvsp[-4].str),(yyvsp[-1].str),(yyvsp[-1].str),(yyvsp[-6].str),(yyvsp[-6].str),(yyvsp[-4].str),(yyvsp[-6].str),(yyvsp[-13].str),(yyvsp[-6].str),(yyvsp[-6].str)); }
#line 2179 "myanalyzer.tab.c"
    break;

  case 113: /* final_type2: token_ident token_arrow2 '[' token_ident '/' token_real token_for token_ident ':' data_type token_in token_ident token_of token_number ']' ':' token_scalar ';'  */
#line 315 "myanalyzer.y"
{ (yyval.str) = template("\n double *%s = (double *)malloc(%s * sizeof(double));\n for(int a_i = 0; a_i < %s;++a_i){\n%s[a_i] =%s[a_i] /  %s;\n};\n",(yyvsp[-17].str)  ,(yyvsp[-4].str),   (yyvsp[-4].str),(yyvsp[-17].str),(yyvsp[-6].str),(yyvsp[-12].str)); }
#line 2185 "myanalyzer.tab.c"
    break;

  case 115: /* expr: '#' token_ident  */
#line 321 "myanalyzer.y"
                  { (yyval.str) = template("self->%s",(yyvsp[0].str)); }
#line 2191 "myanalyzer.tab.c"
    break;

  case 116: /* expr: function_call  */
#line 322 "myanalyzer.y"
                 { (yyval.str) = (yyvsp[0].str); }
#line 2197 "myanalyzer.tab.c"
    break;

  case 117: /* expr: token_ident '[' token_ident ']'  */
#line 323 "myanalyzer.y"
                                         {(yyval.str) = template("%s[%s]", (yyvsp[-3].str), (yyvsp[-1].str));}
#line 2203 "myanalyzer.tab.c"
    break;

  case 118: /* expr: '-' expr  */
#line 324 "myanalyzer.y"
                                 { (yyval.str) = template("-%s",(yyvsp[0].str)); }
#line 2209 "myanalyzer.tab.c"
    break;

  case 119: /* expr: '+' expr  */
#line 325 "myanalyzer.y"
                                 { (yyval.str) = template("+%s",(yyvsp[0].str)); }
#line 2215 "myanalyzer.tab.c"
    break;

  case 120: /* expr: expr token_star expr  */
#line 326 "myanalyzer.y"
                         { (yyval.str) = template("pow(%s,%s)", (yyvsp[-2].str),(yyvsp[0].str)); }
#line 2221 "myanalyzer.tab.c"
    break;

  case 121: /* expr: expr '*' expr  */
#line 327 "myanalyzer.y"
                 { (yyval.str) = template("%s * %s", (yyvsp[-2].str),(yyvsp[0].str)); }
#line 2227 "myanalyzer.tab.c"
    break;

  case 122: /* expr: expr '/' expr  */
#line 328 "myanalyzer.y"
                 { (yyval.str) = template("%s / %s", (yyvsp[-2].str),(yyvsp[0].str)); }
#line 2233 "myanalyzer.tab.c"
    break;

  case 123: /* expr: expr '%' expr  */
#line 329 "myanalyzer.y"
                 { (yyval.str) = template("%s %% %s", (yyvsp[-2].str),(yyvsp[0].str)); }
#line 2239 "myanalyzer.tab.c"
    break;

  case 124: /* expr: expr '+' expr  */
#line 330 "myanalyzer.y"
                { (yyval.str) = template("%s + %s", (yyvsp[-2].str),(yyvsp[0].str)); }
#line 2245 "myanalyzer.tab.c"
    break;

  case 125: /* expr: expr '-' expr  */
#line 331 "myanalyzer.y"
                { (yyval.str) = template("%s - %s", (yyvsp[-2].str),(yyvsp[0].str)); }
#line 2251 "myanalyzer.tab.c"
    break;

  case 126: /* expr: expr op_equal expr  */
#line 332 "myanalyzer.y"
                     { (yyval.str) = template("%s == %s", (yyvsp[-2].str),(yyvsp[0].str)); }
#line 2257 "myanalyzer.tab.c"
    break;

  case 127: /* expr: expr op_noequal expr  */
#line 333 "myanalyzer.y"
                       { (yyval.str) = template("%s != %s", (yyvsp[-2].str),(yyvsp[0].str)); }
#line 2263 "myanalyzer.tab.c"
    break;

  case 128: /* expr: expr '<' expr  */
#line 334 "myanalyzer.y"
                { (yyval.str) = template("%s < %s", (yyvsp[-2].str),(yyvsp[0].str)); }
#line 2269 "myanalyzer.tab.c"
    break;

  case 129: /* expr: expr op_lessequal expr  */
#line 335 "myanalyzer.y"
                         { (yyval.str) = template("%s <= %s", (yyvsp[-2].str),(yyvsp[0].str)); }
#line 2275 "myanalyzer.tab.c"
    break;

  case 130: /* expr: expr '>' expr  */
#line 336 "myanalyzer.y"
                { (yyval.str) = template("%s > %s", (yyvsp[-2].str),(yyvsp[0].str)); }
#line 2281 "myanalyzer.tab.c"
    break;

  case 131: /* expr: expr op_moreequal expr  */
#line 337 "myanalyzer.y"
                         { (yyval.str) = template("%s >=  %s", (yyvsp[-2].str),(yyvsp[0].str)); }
#line 2287 "myanalyzer.tab.c"
    break;

  case 132: /* expr: expr logic_and expr  */
#line 338 "myanalyzer.y"
                      { (yyval.str) = template("%s && %s", (yyvsp[-2].str),(yyvsp[0].str)); }
#line 2293 "myanalyzer.tab.c"
    break;

  case 133: /* expr: expr logic_or expr  */
#line 339 "myanalyzer.y"
                     { (yyval.str) = template("%s || %s", (yyvsp[-2].str),(yyvsp[0].str)); }
#line 2299 "myanalyzer.tab.c"
    break;

  case 134: /* expr: logic_not expr  */
#line 340 "myanalyzer.y"
                 { (yyval.str) = template("!%s", (yyvsp[0].str)); }
#line 2305 "myanalyzer.tab.c"
    break;

  case 135: /* expr: '(' expr ')'  */
#line 341 "myanalyzer.y"
               { (yyval.str) = template("(%s)", (yyvsp[-1].str)); }
#line 2311 "myanalyzer.tab.c"
    break;

  case 136: /* expr_data: token_ident  */
#line 345 "myanalyzer.y"
              { (yyval.str) = template("%s",(yyvsp[0].str)); }
#line 2317 "myanalyzer.tab.c"
    break;

  case 137: /* expr_data: token_constring  */
#line 346 "myanalyzer.y"
                  { (yyval.str) = template("%s",(yyvsp[0].str)); }
#line 2323 "myanalyzer.tab.c"
    break;

  case 138: /* expr_data: token_ident '[' token_number ']'  */
#line 347 "myanalyzer.y"
                                   { (yyval.str) = template("%s[%s]",(yyvsp[-3].str),(yyvsp[-1].str)); }
#line 2329 "myanalyzer.tab.c"
    break;

  case 139: /* expr_data: token_number  */
#line 348 "myanalyzer.y"
                { (yyval.str) = template("%s",(yyvsp[0].str)); }
#line 2335 "myanalyzer.tab.c"
    break;

  case 140: /* expr_data: token_real  */
#line 349 "myanalyzer.y"
              { (yyval.str) = template("%s",(yyvsp[0].str)); }
#line 2341 "myanalyzer.tab.c"
    break;

  case 141: /* expr_data: bool_value  */
#line 350 "myanalyzer.y"
             { (yyval.str) = template("%s ",(yyvsp[0].str)); }
#line 2347 "myanalyzer.tab.c"
    break;


#line 2351 "myanalyzer.tab.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 356 "myanalyzer.y"

int main () {
  if ( yyparse() == 0 ){
    printf("\033[0;32m");
    printf("\nAccept!\n");
  }
  else{
    printf("\033[0;31m");
    printf("Reject!\n");
  }
}

